
Car - v1 2020-06-08 1:25pm
==============================

This dataset was exported via roboflow.ai on June 8, 2020 at 5:25 PM GMT

It includes 153 images.
Car are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


